#!/usr/bin/env python
"""
src/uce_baseline.py -- Phase 0: closed-form UCE-style edit of the cross-attention K/V weights.

No gradient training; runs in a couple of minutes (text encoder forward + a few 768x768 solves).
Writes the SAME file format as the trainer, so model_loader.py can load it:
    python src/uce_baseline.py                       # -> modified_weights/kv_lora_uce.safetensors
    cp modified_weights/kv_lora_uce.safetensors modified_weights/kv_lora.safetensors
    rm -rf generated && python generate_images.py --data_dir ./data_public --out_dir ./generated
    python evaluate.py --data_dir ./data_public --generated_dir ./generated
(delete the extra file before zipping the submission)

Math. Every cross-attn layer applies W (to_k or to_v) to the SAME 768-d text hidden states e.
For edit pairs (e_i -> target embedding t_i) and preserved embeddings p_j the minimiser of
    sum ||W'e_i - W t_i||^2 + lam * sum ||W'p_j - W p_j||^2 + ridge * ||W' - W||_F^2
is   W' = W + (W D) (E^T M^-1),   D = T - E,   M = E E^T + lam * P P^T + ridge * I .
The update has rank <= #edit vectors and is stored as (B = W D, A = E^T M^-1), then SVD-truncated.

Edit pairs (each uses the contextual CLIP hidden state at the token position):
  ERASE  : artist-name tokens (+ first EOS + one pad position) of a styled prompt
           -> (1+eta) * e_neutral - eta * e_styled, where neutral = same prompt with "an artist"
  DEBIAS : role tokens (+ EOS + pad) of the bare role prompt
           -> 0.5 * e("female <role>") + 0.5 * e("male <role>")   (same dual-teacher idea, in embedding space)
  PRESERVE: all tokens up to EOS (+4 pad positions) of retain prompts (neighbour artists, other roles,
           explicit-gender role prompts, generic captions, "").
"""
import argparse
import os
import random
import sys

import torch
from safetensors.torch import save_file

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import concepts as C                                       # noqa: E402
from model_loader import MODEL_ID, REVISION                # noqa: E402
from diffusers import UNet2DConditionModel                 # noqa: E402
from transformers import CLIPTextModel, CLIPTokenizer      # noqa: E402

L = 77
UCE_TEMPLATES = [
    "a painting of {s}, in the style of {a}", "{s}, in the style of {a}", "a painting of {s} by {a}",
    "artwork by {a}", "a painting in the style of {a}", "an oil painting by {a}", "{a}",
]


def find_sub(seq, sub):
    for i in range(len(seq) - len(sub) + 1):
        if seq[i:i + len(sub)] == sub:
            return i
    return -1


class Enc:
    def __init__(self, dev):
        self.dev = dev
        self.tok = CLIPTokenizer.from_pretrained(MODEL_ID, subfolder="tokenizer", revision=REVISION)
        self.te = CLIPTextModel.from_pretrained(MODEL_ID, subfolder="text_encoder",
                                                revision=REVISION).to(dev).eval()
        self.eos = self.tok.eos_token_id

    def sub_ids(self, text):
        return self.tok(text, add_special_tokens=False).input_ids

    @torch.no_grad()
    def __call__(self, prompts):
        ids = self.tok(prompts, padding="max_length", max_length=L, truncation=True,
                       return_tensors="pt").input_ids
        hs = [self.te(ids[i:i + 64].to(self.dev))[0].float().cpu() for i in range(0, len(prompts), 64)]
        return [r.tolist() for r in ids], torch.cat(hs)

    def first_eos(self, id_list):
        return id_list.index(self.eos)


def collect_erase(enc, eta, rng):
    an = enc.sub_ids("an artist")
    ps, pn, al = [], [], []
    for spec in C.ARTISTS.values():
        for alias in C.all_alias_strings(spec):
            for t in UCE_TEMPLATES:
                s = rng.choice(C.SUBJECTS)
                ps.append(t.format(a=alias, s=s)); pn.append(t.format(a="an artist", s=s)); al.append(alias)
    ids_s, Hs = enc(ps)
    ids_n, Hn = enc(pn)
    S, T = [], []
    for i, alias in enumerate(al):
        sub = enc.sub_ids(alias)
        s0, n0 = find_sub(ids_s[i], sub), find_sub(ids_n[i], an)
        if s0 < 0 or n0 < 0:
            continue
        pairs = [(Hs[i, s0 + j], Hn[i, n0 + min(j, len(an) - 1)]) for j in range(len(sub))]
        es, en = enc.first_eos(ids_s[i]), enc.first_eos(ids_n[i])
        pairs.append((Hs[i, es], Hn[i, en]))
        p = max(es, en) + 3
        if p < L:
            pairs.append((Hs[i, p], Hn[i, p]))
        for e_c, e_n in pairs:
            S.append(e_c); T.append((1 + eta) * e_n - eta * e_c)
    return S, T


def collect_debias(enc):
    trip, roles = [], []
    for role in C.ROLES:
        for t in C.ROLE_TEMPLATES:
            trip += [t.format(r=role), C.gendered(t, role, "female"), C.gendered(t, role, "male")]
            roles.append(role)
    ids, H = enc(trip)
    S, T = [], []
    for i, role in enumerate(roles):
        b, f, m = 3 * i, 3 * i + 1, 3 * i + 2
        sub = enc.sub_ids(role)
        b0, f0, m0 = (find_sub(ids[k], sub) for k in (b, f, m))
        if min(b0, f0, m0) < 0:
            continue
        pairs = [(H[b, b0 + j], 0.5 * (H[f, f0 + j] + H[m, m0 + j])) for j in range(len(sub))]
        eb, ef, em = (enc.first_eos(ids[k]) for k in (b, f, m))
        pairs.append((H[b, eb], 0.5 * (H[f, ef] + H[m, em])))
        p = max(eb, ef, em) + 3
        if p < L:
            pairs.append((H[b, p], 0.5 * (H[f, p] + H[m, p])))
        for e_c, tgt in pairs:
            S.append(e_c); T.append(tgt)
    return S, T


def collect_preserve(enc, rng, n):
    prompts = [""]
    prompts += [C.sample_retain_style(rng) for _ in range(n)]
    prompts += [C.sample_retain_role(rng) for _ in range(n)]
    prompts += [C.sample_retain_generic(rng) for _ in range(n // 2)]
    ids, H = enc(prompts)
    P = []
    for i in range(len(prompts)):
        eos = enc.first_eos(ids[i])
        idx = list(range(0, eos + 1))
        if eos + 1 < L:
            idx += torch.linspace(eos + 1, L - 1, 4).round().long().tolist()
        P.append(H[i, idx])
    return torch.cat(P)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(ROOT, "modified_weights", "kv_lora_uce.safetensors"))
    ap.add_argument("--eta", type=float, default=1.0, help="erasure negative guidance")
    ap.add_argument("--lam", type=float, default=1.0, help="preservation weight")
    ap.add_argument("--ridge", type=float, default=0.02, help="ridge, relative to mean diag(M)")
    ap.add_argument("--max_rank", type=int, default=128)
    ap.add_argument("--n_preserve", type=int, default=300)
    ap.add_argument("--no_erase", action="store_true")
    ap.add_argument("--no_debias", action="store_true")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    rng = random.Random(a.seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    enc = Enc(dev)

    S, T = [], []
    if not a.no_erase:
        s, t = collect_erase(enc, a.eta, rng); S += s; T += t
        print(f"[uce] erase edit vectors : {len(s)}")
    if not a.no_debias:
        s, t = collect_debias(enc); S += s; T += t
        print(f"[uce] debias edit vectors: {len(s)}")
    assert S, "nothing to edit"
    P = collect_preserve(enc, rng, a.n_preserve)
    print(f"[uce] preserve vectors   : {P.shape[0]}")

    E = torch.stack(S, 1).double()            # (768, n)
    Tm = torch.stack(T, 1).double()
    D = Tm - E
    P = P.T.double()                          # (768, m)
    M = E @ E.T + a.lam * (P @ P.T)
    M += a.ridge * M.diagonal().mean() * torch.eye(M.shape[0], dtype=torch.float64)
    Amat = torch.linalg.solve(M, E).T         # = E^T M^-1  (n, 768)  (M symmetric)

    unet = UNet2DConditionModel.from_pretrained(MODEL_ID, subfolder="unet", revision=REVISION,
                                                torch_dtype=torch.float32)
    tensors, n_layers = {}, 0
    for name, m in unet.named_modules():
        if name.endswith("attn2") and hasattr(m, "to_k") and hasattr(m, "to_v"):
            for proj in ("to_k", "to_v"):
                W = getattr(m, proj).weight.data.double()
                delta = (W @ D) @ Amat                                   # (out, 768)
                U, Sv, Vh = torch.linalg.svd(delta, full_matrices=False)
                r = min(a.max_rank, Sv.numel())
                energy = float((Sv[:r] ** 2).sum() / (Sv ** 2).sum())
                tensors[f"{name}.{proj}.lora_B"] = (U[:, :r] * Sv[:r]).float().contiguous()
                tensors[f"{name}.{proj}.lora_A"] = Vh[:r].float().contiguous()
                n_layers += 1
                if n_layers <= 2 or n_layers == 32:
                    print(f"[uce] {name}.{proj}: |dW|/|W| = {float(delta.norm() / W.norm()):.4f}, "
                          f"rank {r}, energy kept {energy:.3f}")
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    save_file(tensors, a.out, metadata={"format": "kv_lora", "scale": "1.0", "version": "1"})
    print(f"[uce] wrote {n_layers} projections -> {a.out} ({os.path.getsize(a.out) / 1e6:.1f} MB)")


if __name__ == "__main__":
    main()
