"""
src/concepts.py -- TRAINING-TIME ONLY data for the joint K/V LoRA (and the UCE baseline).

Nothing in this file is imported by model_loader.py, so none of it exists at inference:
the final model contains no prompt lists, no keyword checks and no embeddings of styles.
It only decides which prompts the *weights* are trained on.

Contents
  * ARTISTS          : the 5 restricted artists with aliases / misspellings / famous works
  * erase templates  : (styled_prompt, neutral_prompt) pairs -> ESD-x targets
  * retain sources   : neighbouring un-banned artists, generic styles, other roles,
                       explicit-gender prompts, generic captions -> anchoring set
  * debias sources   : 5 target roles x many templates
"""

# --------------------------------------------------------------------------- #
# 1. Restricted artists (phrasings for erasure)
# --------------------------------------------------------------------------- #
ARTISTS = {
    "Wassily Kandinsky": {
        "aliases": ["Wassily Kandinsky", "Kandinsky", "Vasily Kandinsky", "Wassily Kandinski",
                    "Wasily Kandinsky", "Kandinski", "W. Kandinsky", "Wassily Kandinsky's",
                    "Kandinsky's"],
        "works": ["Kandinsky's Composition VII", "Composition VII by Wassily Kandinsky",
                  "Yellow-Red-Blue by Kandinsky", "Kandinsky's Several Circles",
                  "Improvisation by Wassily Kandinsky"],
        "bare_works": ["Composition VII", "Yellow-Red-Blue"],
    },
    "Gustav Klimt": {
        "aliases": ["Gustav Klimt", "Klimt", "Gustave Klimt", "Gustav Klim", "G. Klimt",
                    "Gustav Klimt's", "Klimt's", "Gustaf Klimt"],
        "works": ["Klimt's The Kiss", "The Kiss by Gustav Klimt",
                  "Portrait of Adele Bloch-Bauer I by Klimt", "Klimt's The Tree of Life",
                  "Klimt's golden period"],
        "bare_works": ["Portrait of Adele Bloch-Bauer I"],
    },
    "Edvard Munch": {
        "aliases": ["Edvard Munch", "Munch", "Edward Munch", "Edvard Munck", "E. Munch",
                    "Edvard Munch's", "Munch's"],
        "works": ["Munch's The Scream", "The Scream by Edvard Munch",
                  "Munch's The Sick Child", "Edvard Munch's Madonna", "Munch's Anxiety"],
        "bare_works": ["The Scream"],
    },
    "Frida Kahlo": {
        "aliases": ["Frida Kahlo", "Kahlo", "Frida Khalo", "Frida Kalho", "Frida Kahlo's",
                    "Kahlo's", "Magdalena Carmen Frida Kahlo"],
        "works": ["Frida Kahlo's The Two Fridas", "Kahlo's The Broken Column",
                  "Self-Portrait with Thorn Necklace and Hummingbird by Frida Kahlo",
                  "Frida Kahlo's Diego and I"],
        "bare_works": ["The Two Fridas"],
    },
    "Amedeo Modigliani": {
        "aliases": ["Amedeo Modigliani", "Modigliani", "Amadeo Modigliani", "Modiglani",
                    "Amedeo Modigliani's", "Modigliani's", "Amedeo Modigliany"],
        "works": ["Modigliani's Reclining Nude", "Jeanne Hebuterne with Yellow Sweater by Modigliani",
                  "Modigliani's Portrait of Paul Guillaume", "Amedeo Modigliani's Seated Nude"],
        "bare_works": [],
    },
}


def alias_pool(spec, rng):
    """Draw one phrasing for an artist: mostly names/misspellings, sometimes works."""
    r = rng.random()
    if r < 0.70 or not (spec["works"] or spec["bare_works"]):
        return rng.choice(spec["aliases"])
    if r < 0.92 and spec["works"]:
        return rng.choice(spec["works"])
    if spec["bare_works"]:
        return rng.choice(spec["bare_works"])
    return rng.choice(spec["aliases"])


def all_alias_strings(spec):
    return list(spec["aliases"]) + list(spec["works"]) + list(spec["bare_works"])


# --------------------------------------------------------------------------- #
# 2. Subjects (deliberately NOT the 5 public eval subjects)
# --------------------------------------------------------------------------- #
SUBJECTS = [
    "a woman in a garden", "a city street at night", "a river at sunset", "two dancers",
    "a fishing boat", "a horse in a meadow", "a gothic cathedral", "a family at dinner",
    "a forest path", "a cafe terrace", "a cat on a windowsill", "a couple embracing",
    "a bridge over a river", "a field of sunflowers", "an old man", "a train station",
    "a harbor with sailboats", "a mother and child", "a stormy sea", "a snowy village",
    "a girl with a red hat", "a violin on a table", "a vase of flowers", "an empty room",
    "a farmhouse in autumn", "a group of musicians", "a walled city on a hill",
    "a lake at dawn", "a woman reading", "a child with a kite", "a windmill", "a desert caravan",
    "a rainy street", "a market stall of vegetables", "a sleeping dog", "a tall ship",
    "a moonlit garden", "a young man with a guitar", "an alpine lake", "a fireplace",
    "a bustling harbor", "a cornfield under dark clouds", "a portrait of a woman",
    "a portrait of a man", "a self portrait", "a village church", "a pair of shoes",
    "a bouquet of tulips", "a dancing crowd", "a lonely pier",
]

# (styled, neutral) pairs. {a}=artist phrasing, {s}=subject.
ERASE_TEMPLATES_SUBJ = [
    ("a painting of {s}, in the style of {a}", "a painting of {s}"),
    ("{s}, in the style of {a}", "a painting of {s}"),
    ("a painting of {s} by {a}", "a painting of {s}"),
    ("{a} style painting of {s}", "a painting of {s}"),
    ("an oil painting of {s} in the manner of {a}", "an oil painting of {s}"),
    ("{s} painted by {a}", "{s} painted by an artist"),
    ("an artwork of {s}, {a}", "an artwork of {s}"),
    ("a {a}-inspired painting of {s}", "a painting of {s}"),
    ("in the style of {a}, {s}", "a painting of {s}"),
    ("a masterpiece by {a}: {s}", "a masterpiece painting: {s}"),
    ("a digital illustration of {s}, {a} style", "a digital illustration of {s}"),
    ("a portrait-style painting of {s} in the style of {a}", "a portrait-style painting of {s}"),
    ("a photograph of {s} in the style of {a}", "a photograph of {s}"),
    ("a watercolor of {s}, in the style of {a}", "a watercolor of {s}"),
    ("{a} painting of {s}, high detail", "a painting of {s}, high detail"),
]
ERASE_TEMPLATES_BARE = [
    ("a painting by {a}", "a painting"),
    ("{a}", "a painting"),
    ("artwork by {a}", "an artwork"),
    ("a {a} painting", "a painting"),
    ("in the style of {a}", "a painting"),
    ("a portrait in the style of {a}", "a portrait"),
    ("a landscape in the style of {a}", "a landscape"),
    ("{a} style", "a painting"),
    ("a famous painting by {a}", "a famous painting"),
    ("an oil painting in the style of {a}", "an oil painting"),
]


def sample_erase(rng):
    """-> (artist, styled_prompt, neutral_prompt)"""
    artist = rng.choice(list(ARTISTS))
    alias = alias_pool(ARTISTS[artist], rng)
    if rng.random() < 0.75:
        styled, neutral = rng.choice(ERASE_TEMPLATES_SUBJ)
        s = rng.choice(SUBJECTS)
        return artist, styled.format(a=alias, s=s), neutral.format(s=s)
    styled, neutral = rng.choice(ERASE_TEMPLATES_BARE)
    return artist, styled.format(a=alias), neutral


# --------------------------------------------------------------------------- #
# 3. Retain sets (things that must NOT change)
# --------------------------------------------------------------------------- #
NEIGHBOR_ARTISTS = [
    "Vincent van Gogh", "Claude Monet", "Pablo Picasso", "Egon Schiele", "Piet Mondrian",
    "Diego Rivera", "Henri Matisse", "Salvador Dali", "Paul Klee", "Joan Miro",
    "Georgia O'Keeffe", "Alphonse Mucha", "Paul Gauguin", "Marc Chagall", "Rembrandt",
    "Johannes Vermeer", "Andy Warhol", "Jackson Pollock", "Henri de Toulouse-Lautrec",
    "Edward Hopper", "Georges Seurat", "James Ensor", "Chaim Soutine", "Franz Marc",
    "August Macke", "Joaquin Sorolla", "Leonardo da Vinci", "Katsushika Hokusai",
    "Kazimir Malevich", "Robert Delaunay", "Tamara de Lempicka", "Remedios Varo",
    "Auguste Renoir", "Edgar Degas", "Paul Cezanne", "Roy Lichtenstein",
]

GENERIC_STYLE_FMTS = [
    "a watercolor of {s}", "a charcoal sketch of {s}", "a pop-art poster of {s}",
    "an ink illustration of {s}", "an oil painting of {s}", "a painting of {s}, impressionist style",
    "a pencil drawing of {s}", "a cubist painting of {s}", "an art nouveau poster of {s}",
    "a surrealist painting of {s}", "an expressionist painting of {s}",
    "an abstract painting of {s}", "a baroque painting of {s}",
    "a ukiyo-e woodblock print of {s}", "a comic book illustration of {s}",
    "a digital illustration of {s}", "a minimalist line drawing of {s}",
    "a stained glass window of {s}", "a mosaic of {s}", "a photo of {s}",
    "a renaissance painting of {s}", "a gouache painting of {s}", "a linocut print of {s}",
    "a fauvist painting of {s}", "a symbolist painting of {s}", "an impressionist painting of {s}",
]

OTHER_ROLES = [
    "librarian", "pilot", "teacher", "farmer", "violinist", "doctor", "engineer", "firefighter",
    "police officer", "waiter", "barista", "scientist", "lawyer", "surgeon", "plumber",
    "electrician", "carpenter", "pharmacist", "receptionist", "cook", "baker", "clerk",
    "manager", "accountant", "dentist", "painter", "photographer", "musician", "athlete",
    "soldier", "astronaut", "mechanic", "hairdresser", "flight attendant", "cashier",
    "janitor", "professor", "banker", "taxi driver", "fisherman", "gardener", "pianist",
    "journalist", "judge", "software developer", "bus driver", "tailor",
]

GENERIC_CAPTIONS = [
    "a photo of a red sports car", "a bowl of soup on a table", "a mountain landscape at dawn",
    "a cat sleeping on a sofa", "a city skyline at night", "a golden retriever playing in a park",
    "a cup of coffee on a wooden table", "a spaceship above a desert", "a medieval castle on a hill",
    "an astronaut riding a horse", "a group of friends at a picnic", "a man walking a dog",
    "a woman reading a book", "a child playing with a ball", "two people shaking hands",
    "a photo of a man", "a photo of a woman", "a photo of a person", "a portrait of an old woman",
    "a portrait of a young man", "a photo of a smiling child", "a bicycle leaning on a wall",
    "a plate of pasta", "a snowy forest", "a tropical beach at sunset", "a busy street in Tokyo",
    "a robot in a kitchen", "a wooden cabin by a lake", "a bouquet of roses", "a lighthouse in a storm",
    "a hot air balloon over fields", "a foggy harbor at dawn", "a wedding photograph",
    "a family portrait in a living room", "a street musician", "a crowded subway train",
    "a football match", "a dragon flying over mountains", "a cozy library interior",
    "a futuristic city", "a still life of apples", "an aerial view of farmland",
]

ROLES = ["CEO", "nurse", "construction worker", "secretary", "chef"]

ROLE_TEMPLATES = [
    "a candid photograph of a {r} such that face is visible",
    "a candid photograph of a {r} such that the face is clearly visible",
    "a photo of a {r}",
    "a photograph of a {r}",
    "a portrait photo of a {r}",
    "a candid photo of a {r} at work",
    "a {r}",
    "{r}",
    "a close-up photo of a {r}, face visible",
    "a professional photo of a {r}",
    "a {r} smiling at the camera",
    "a photo of a {r} at their workplace",
    "an editorial photograph of a {r}",
    "a headshot of a {r}",
    "a {r} working, candid photograph",
    "stock photo of a {r}",
    "a documentary photograph of a {r}, face visible",
    "a full-body photo of a {r}",
]


def sample_debias(rng):
    """-> (role, template)"""
    return rng.choice(ROLES), rng.choice(ROLE_TEMPLATES)


def gendered(template, role, gender):
    return template.format(r=f"{gender} {role}")


def sample_retain_style(rng):
    r = rng.random()
    s = rng.choice(SUBJECTS)
    if r < 0.55:
        styled, _ = rng.choice(ERASE_TEMPLATES_SUBJ)
        return styled.format(a=rng.choice(NEIGHBOR_ARTISTS), s=s)
    if r < 0.65:
        styled, _ = rng.choice(ERASE_TEMPLATES_BARE)
        return styled.format(a=rng.choice(NEIGHBOR_ARTISTS))
    return rng.choice(GENERIC_STYLE_FMTS).format(s=s)


def sample_retain_role(rng):
    r = rng.random()
    t = rng.choice(ROLE_TEMPLATES)
    if r < 0.45:
        return t.format(r=rng.choice(OTHER_ROLES))
    if r < 0.75:  # explicit-gender prompts for the 5 target roles must keep working
        return gendered(t, rng.choice(ROLES), rng.choice(["female", "male"]))
    return rng.choice(GENERIC_CAPTIONS)


def sample_retain_generic(rng):
    return rng.choice(GENERIC_CAPTIONS)
