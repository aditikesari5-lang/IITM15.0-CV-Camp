#!/usr/bin/env python
"""
src/train_unlearn_debias.py
Joint K/V-LoRA training:  hardened ESD-x (5 artists)  +  dual-teacher debiasing (5 roles)
                          +  retain anchoring (style_preserver / bias_preserver protection)

Only the UNet *cross-attention* to_k / to_v projections (attn2) receive LoRA adapters; every
other weight stays frozen. Output: modified_weights/kv_lora.safetensors (a few MB) which
model_loader.load_model() fuses into the UNet weights.

Run from the repo root (Colab/Kaggle T4, needs CUDA):
    python src/train_unlearn_debias.py --iters 1000
Smoke test:
    python src/train_unlearn_debias.py --iters 3 --save_every 1 --out /tmp/test.safetensors

Losses per iteration (x_t is sampled by DDIM to a random step, ESD-style; one x_t per task):
  ERASE  : student eps(x_t, styled) -> eps_b(neutral) - eta * (eps_b(styled) - eps_b(neutral))
           ("neutral" = same prompt with the artist phrase removed, so subject/medium survive)
  DEBIAS : student eps(x_t, bare role) -> 0.5*eps_b(x_t,"female role") + 0.5*eps_b(x_t,"male role")
           (or --debias_target sampled : eps_b of the gender that generated the trajectory)
  RETAIN : student eps(x_t, retain prompt) -> eps_b(x_t, retain prompt)   (MSE, incl. "" for CFG)
eps_b = the frozen base model = same UNet with the LoRA switched off.

This script never builds the full pipeline (no VAE / safety checker is needed for latent-space
training); the submitted pipeline in model_loader.py keeps the safety checker active.
"""
import argparse
import math
import os
import random
import sys
import time

import torch
import torch.nn as nn
import torch.nn.functional as F
from safetensors.torch import load_file, save_file

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import concepts as C                                     # noqa: E402
from model_loader import MODEL_ID, REVISION              # noqa: E402  (single source of truth)
from diffusers import DDIMScheduler, UNet2DConditionModel  # noqa: E402
from transformers import CLIPTextModel, CLIPTokenizer    # noqa: E402

DEV = "cuda"
DT = torch.float16


# --------------------------------------------------------------------------- #
# LoRA on cross-attention K/V
# --------------------------------------------------------------------------- #
class LoRALinear(nn.Module):
    def __init__(self, base: nn.Linear, rank: int, alpha: float):
        super().__init__()
        self.base = base
        self.scale = alpha / rank
        dev = base.weight.device
        self.lora_A = nn.Parameter(torch.empty(rank, base.in_features, device=dev, dtype=torch.float32))
        self.lora_B = nn.Parameter(torch.zeros(base.out_features, rank, device=dev, dtype=torch.float32))
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        self.enabled = True

    def forward(self, x):
        out = self.base(x)
        if self.enabled:
            d = F.linear(F.linear(x.float(), self.lora_A), self.lora_B) * self.scale
            out = out + d.to(out.dtype)
        return out


def inject_kv_lora(unet, rank, alpha):
    """Wrap attn2.to_k / attn2.to_v (cross-attention only; self-attention attn1 is untouched)."""
    mods = []
    for name, m in list(unet.named_modules()):
        if name.endswith("attn2") and hasattr(m, "to_k") and hasattr(m, "to_v"):
            for proj in ("to_k", "to_v"):
                w = LoRALinear(getattr(m, proj), rank, alpha)
                setattr(m, proj, w)
                mods.append((f"{name}.{proj}", w))
    return mods


def save_lora(path, mods, rank, alpha):
    tensors = {}
    for name, m in mods:
        tensors[f"{name}.lora_A"] = m.lora_A.detach().float().cpu().contiguous()
        tensors[f"{name}.lora_B"] = m.lora_B.detach().float().cpu().contiguous()
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    save_file(tensors, tmp, metadata={"format": "kv_lora", "scale": str(alpha / rank), "version": "1"})
    os.replace(tmp, path)


def load_lora_into(path, mods):
    tensors = load_file(path)
    for name, m in mods:
        m.lora_A.data.copy_(tensors[f"{name}.lora_A"].to(m.lora_A.device))
        m.lora_B.data.copy_(tensors[f"{name}.lora_B"].to(m.lora_B.device))


# --------------------------------------------------------------------------- #
# Trainer
# --------------------------------------------------------------------------- #
class Trainer:
    def __init__(self, args):
        self.a = args
        self.rng = random.Random(args.seed)
        torch.manual_seed(args.seed)
        self.gen = torch.Generator(device=DEV).manual_seed(args.seed)

        self.tok = CLIPTokenizer.from_pretrained(MODEL_ID, subfolder="tokenizer", revision=REVISION)
        self.te = CLIPTextModel.from_pretrained(MODEL_ID, subfolder="text_encoder", revision=REVISION,
                                                torch_dtype=DT).to(DEV).eval()
        self.unet = UNet2DConditionModel.from_pretrained(MODEL_ID, subfolder="unet", revision=REVISION,
                                                         torch_dtype=DT).to(DEV)
        self.sched = DDIMScheduler.from_pretrained(MODEL_ID, subfolder="scheduler", revision=REVISION)
        self.sched.set_timesteps(args.sample_steps)
        self.ts = [int(t) for t in self.sched.timesteps]
        self.step_size = 1000 // args.sample_steps
        self.acp = self.sched.alphas_cumprod.float()
        self.final_acp = float(self.sched.final_alpha_cumprod)

        for p in self.te.parameters():
            p.requires_grad_(False)
        for p in self.unet.parameters():
            p.requires_grad_(False)
        self.mods = inject_kv_lora(self.unet, args.rank, args.alpha)
        assert len(self.mods) > 0, "no cross-attention to_k/to_v found"
        print(f"[init] LoRA on {len(self.mods)} projections, "
              f"{sum(m.lora_A.numel() + m.lora_B.numel() for _, m in self.mods) / 1e6:.2f}M trainable params")
        self.unet.enable_gradient_checkpointing()
        self.unet.train()  # SD-UNet has no dropout; train() only enables gradient checkpointing

        self.params = [p for _, m in self.mods for p in (m.lora_A, m.lora_B)]
        if args.resume and os.path.exists(args.out):
            load_lora_into(args.out, self.mods)
            print(f"[init] resumed weights from {args.out}")
        self.opt = torch.optim.AdamW(self.params, lr=args.lr, weight_decay=0.0)
        try:
            self.scaler = torch.amp.GradScaler("cuda", init_scale=2.0 ** 10)
        except (AttributeError, TypeError):
            self.scaler = torch.cuda.amp.GradScaler(init_scale=2.0 ** 10)
        self.emb_u = self.enc([""])

    # -- helpers ----------------------------------------------------------- #
    def set_lora(self, on):
        for _, m in self.mods:
            m.enabled = on

    @torch.no_grad()
    def enc(self, prompts):
        ids = self.tok(prompts, padding="max_length", max_length=self.tok.model_max_length,
                       truncation=True, return_tensors="pt").input_ids.to(DEV)
        return self.te(ids)[0]

    def _ddim(self, eps, t, lat):
        a_t = float(self.acp[t])
        prev = t - self.step_size
        a_p = float(self.acp[prev]) if prev >= 0 else self.final_acp
        lat32, eps32 = lat.float(), eps.float()
        x0 = (lat32 - (1 - a_t) ** 0.5 * eps32) / a_t ** 0.5
        return (a_p ** 0.5 * x0 + (1 - a_p) ** 0.5 * eps32).to(DT)

    @torch.no_grad()
    def sample_xt(self, emb_c, k, lora_on):
        """Run DDIM from noise for k steps with CFG; return (x_t, t) at step k."""
        self.set_lora(lora_on)
        g = self.rng.uniform(self.a.guidance_min, self.a.guidance_max)
        lat = torch.randn((1, 4, 64, 64), generator=self.gen, device=DEV, dtype=DT)
        cond = torch.cat([self.emb_u, emb_c])
        for i in range(k):
            t = self.ts[i]
            e = self.unet(torch.cat([lat, lat]), torch.tensor(t, device=DEV),
                          encoder_hidden_states=cond).sample
            eu, ec = e.chunk(2)
            lat = self._ddim(eu + g * (ec - eu), t, lat)
        return lat, self.ts[k]

    @torch.no_grad()
    def base_eps(self, lat, t, emb):
        self.set_lora(False)
        return self.unet(lat.expand(emb.shape[0], -1, -1, -1), torch.tensor(t, device=DEV),
                         encoder_hidden_states=emb).sample

    def student_eps(self, lat, t, emb):
        self.set_lora(True)
        return self.unet(lat.expand(emb.shape[0], -1, -1, -1), torch.tensor(t, device=DEV),
                         encoder_hidden_states=emb).sample

    def _retain(self, sampler, n):
        return [sampler(self.rng) for _ in range(n - 1)] + [""]  # always anchor the unconditional prompt

    def _backward(self, loss):
        self.scaler.scale(loss).backward()

    # -- task 1: hardened ESD-x -------------------------------------------- #
    def erase_step(self):
        a, R = self.a, self.a.retain_bs
        _, styled, neutral = C.sample_erase(self.rng)
        retain = self._retain(lambda r: C.sample_retain_style(r) if r.random() < 0.7
                              else C.sample_retain_generic(r), R)
        emb = self.enc([styled, neutral] + retain)                     # (2+R, 77, 768)
        k = self.rng.randrange(a.sample_steps)
        lat, t = self.sample_xt(emb[0:1], k, lora_on=self.rng.random() < a.onpolicy_prob)

        eb = self.base_eps(lat, t, emb)
        target_erase = eb[1] - a.neg_guidance * (eb[0] - eb[1])
        target = torch.cat([target_erase[None], eb[2:]])
        pred = self.student_eps(lat, t, torch.cat([emb[0:1], emb[2:]]))

        l_e = F.mse_loss(pred[0].float(), target[0].float())
        l_r = F.mse_loss(pred[1:].float(), target[1:].float())
        self._backward(a.w_erase * l_e + a.w_retain * l_r)
        return l_e.item(), l_r.item()

    # -- task 2: dual-teacher debiasing ------------------------------------ #
    def debias_step(self):
        a, R = self.a, self.a.retain_bs
        role, tmpl = C.sample_debias(self.rng)
        bare = tmpl.format(r=role)
        fem, mal = C.gendered(tmpl, role, "female"), C.gendered(tmpl, role, "male")
        retain = self._retain(C.sample_retain_role, R)
        emb = self.enc([bare, fem, mal] + retain)                      # (3+R, 77, 768)
        k = self.rng.randrange(a.sample_steps)

        g_idx = self.rng.randrange(2)
        if a.debias_target == "avg" and self.rng.random() < a.onpolicy_prob:
            lat, t = self.sample_xt(emb[0:1], k, lora_on=True)          # student's own trajectory
        else:                                                           # base, random gendered prompt
            lat, t = self.sample_xt(emb[1 + g_idx:2 + g_idx], k, lora_on=False)

        eb = self.base_eps(lat, t, emb)
        if a.debias_target == "avg":
            tgt_d = 0.5 * eb[1] + 0.5 * eb[2]
        else:  # 'sampled': regression to the teacher that produced the trajectory -> posterior mixture
            tgt_d = eb[1 + g_idx]
        target = torch.cat([tgt_d[None], eb[3:]])
        pred = self.student_eps(lat, t, torch.cat([emb[0:1], emb[3:]]))

        l_d = F.mse_loss(pred[0].float(), target[0].float())
        l_r = F.mse_loss(pred[1:].float(), target[1:].float())
        self._backward(a.w_debias * l_d + a.w_retain * l_r)
        return l_d.item(), l_r.item()

    def lr_at(self, it):
        a = self.a
        if it < a.warmup:
            return a.lr * (it + 1) / a.warmup
        p = (it - a.warmup) / max(1, a.iters - a.warmup)
        return a.lr * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * p)))

    def run(self):
        a = self.a
        t0 = time.time()
        acc = [0.0] * 4
        for it in range(a.iters):
            for g in self.opt.param_groups:
                g["lr"] = self.lr_at(it)
            self.opt.zero_grad(set_to_none=True)
            le, lre = self.erase_step()
            ld, lrd = self.debias_step()
            self.scaler.unscale_(self.opt)
            torch.nn.utils.clip_grad_norm_(self.params, 1.0)
            self.scaler.step(self.opt)
            self.scaler.update()
            for i, v in enumerate((le, lre, ld, lrd)):
                acc[i] += v
            if (it + 1) % a.log_every == 0:
                n = a.log_every
                print(f"[{it + 1:5d}/{a.iters}] erase {acc[0] / n:.4f} (ret {acc[1] / n:.5f}) | "
                      f"debias {acc[2] / n:.4f} (ret {acc[3] / n:.5f}) | "
                      f"lr {self.lr_at(it):.2e} | {(time.time() - t0) / (it + 1):.1f}s/it", flush=True)
                acc = [0.0] * 4
            if (it + 1) % a.save_every == 0 or it + 1 == a.iters:
                save_lora(a.out, self.mods, a.rank, a.alpha)
        print(f"[done] saved {a.out}  ({os.path.getsize(a.out) / 1e6:.1f} MB)")


def parse():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default=os.path.join(ROOT, "modified_weights", "kv_lora.safetensors"))
    p.add_argument("--iters", type=int, default=1000)
    p.add_argument("--rank", type=int, default=32)
    p.add_argument("--alpha", type=float, default=32.0)
    p.add_argument("--lr", type=float, default=1e-4)
    p.add_argument("--warmup", type=int, default=20)
    p.add_argument("--sample_steps", type=int, default=20, help="DDIM steps used to reach x_t")
    p.add_argument("--guidance_min", type=float, default=3.0)
    p.add_argument("--guidance_max", type=float, default=7.5)
    p.add_argument("--neg_guidance", type=float, default=1.0, help="ESD eta")
    p.add_argument("--w_erase", type=float, default=1.0)
    p.add_argument("--w_debias", type=float, default=1.0)
    p.add_argument("--w_retain", type=float, default=5.0)
    p.add_argument("--retain_bs", type=int, default=3, help="retain prompts per task incl. the empty prompt")
    p.add_argument("--debias_target", choices=["avg", "sampled"], default="avg")
    p.add_argument("--onpolicy_prob", type=float, default=0.5)
    p.add_argument("--save_every", type=int, default=100)
    p.add_argument("--log_every", type=int, default=10)
    p.add_argument("--resume", action="store_true")
    p.add_argument("--seed", type=int, default=0)
    return p.parse_args()


if __name__ == "__main__":
    assert torch.cuda.is_available(), "training needs a CUDA GPU (Colab/Kaggle T4 is fine)"
    Trainer(parse()).run()
