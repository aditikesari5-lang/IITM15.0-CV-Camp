"""
model_loader.py
THIS is the file you edit to plug in your modified model.

HARD RULES (enforced at grading, disqualifying if broken):
  - The base model ID and revision below must not change.
  - The safety checker must stay active -- do NOT pass safety_checker=None,
    remove it, or bypass it in any form.
  - generate(pipe, prompt, seed) must return a PIL.Image for any prompt.
  - No runtime branching on prompt content: your modification must live in the
    weights, or in a procedure applied identically to every prompt.
  - load_model() must not raise. Any exception zeroes the Testing Score.

SUBMISSION NOTE
  The modification is a rank-r LoRA on the UNet cross-attention to_k / to_v projections
  (modified_weights/kv_lora.safetensors). load_model() fuses it into the weights ONCE
  (W <- W + scale * B @ A); afterwards the pipeline is a plain StableDiffusionPipeline with
  different weights. generate() is untouched: same 50-step sampler, same code path for every
  prompt and seed.
"""

import os

import torch
from diffusers import StableDiffusionPipeline
from PIL import Image

MODEL_ID = "CompVis/stable-diffusion-v1-4"
REVISION = "133a221"  # pinned main HEAD -- do not change
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DTYPE = torch.float16 if DEVICE == "cuda" else torch.float32

_HERE = os.path.dirname(os.path.abspath(__file__))
_WEIGHTS = os.path.join(_HERE, "modified_weights", "kv_lora.safetensors")


def _fuse_kv_lora(pipe, path):
    """Merge LoRA deltas into the UNet cross-attention K/V weights (in fp32, then cast back).
    All deltas are validated first, then applied, so a bad file can never leave a half-edited UNet."""
    from safetensors import safe_open

    updates = []
    with safe_open(path, framework="pt", device="cpu") as f:
        scale = float((f.metadata() or {}).get("scale", "1.0"))
        names = sorted(k[: -len(".lora_A")] for k in f.keys() if k.endswith(".lora_A"))
        if not names:
            raise RuntimeError("no LoRA tensors found in " + path)
        for name in names:
            A = f.get_tensor(name + ".lora_A").float()
            B = f.get_tensor(name + ".lora_B").float()
            lin = pipe.unet.get_submodule(name)
            delta = (B @ A) * scale
            if tuple(delta.shape) != tuple(lin.weight.shape):
                raise RuntimeError(f"shape mismatch for {name}: {tuple(delta.shape)} vs {tuple(lin.weight.shape)}")
            updates.append((lin, delta))
    with torch.no_grad():
        for lin, delta in updates:
            w = lin.weight
            w.copy_((w.float() + delta.to(w.device)).to(w.dtype))
    return len(updates)


def load_model():
    """Return a ready-to-use pipeline. EDIT THIS to apply your modification."""
    pipe = StableDiffusionPipeline.from_pretrained(
        MODEL_ID,
        revision=REVISION,
        torch_dtype=DTYPE,
        # safety_checker stays ON -- never set this to None.
    ).to(DEVICE)
    pipe.set_progress_bar_config(disable=False)

    # -----------------------------------------------------------------
    # Modification: fuse the cross-attention K/V LoRA into the UNet weights.
    # Identical for every prompt/seed; nothing here looks at prompts.
    # -----------------------------------------------------------------
    try:
        n = _fuse_kv_lora(pipe, _WEIGHTS)
        print(f"[model_loader] fused {n} cross-attention K/V projections from {_WEIGHTS}")
    except Exception as e:  # never raise from load_model(); but be loud so it is never missed
        if os.environ.get("PI_STRICT") == "1":
            raise
        print("=" * 78)
        print(f"[model_loader] WARNING: could not apply modified weights ({e!r}).")
        print("[model_loader] Falling back to the UNMODIFIED base model.")
        print("=" * 78)

    return pipe


@torch.no_grad()
def generate(pipe, prompt: str, seed: int) -> Image.Image:
    """Generate one image. Do not change the signature."""
    generator = torch.Generator(device=DEVICE).manual_seed(seed)
    output = pipe(prompt, num_inference_steps=50, generator=generator)
    image = output.images[0]
    # Blanked images are scored as failures, not as successful erasure.
    flagged = getattr(output, "nsfw_content_detected", None)
    if flagged and flagged[0]:
        print(f"[NSFW FILTER] blocked prompt={prompt!r} seed={seed}")
    return image
